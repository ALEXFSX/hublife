-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 21, 2021 at 05:47 PM
-- Server version: 5.7.30
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atts_hublife_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_cli_cookie_scan`
--

CREATE TABLE `atts_wp_cli_cookie_scan` (
  `id_cli_cookie_scan` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `total_url` int(11) NOT NULL DEFAULT '0',
  `total_cookies` int(11) NOT NULL DEFAULT '0',
  `current_action` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `current_offset` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_cli_cookie_scan_categories`
--

CREATE TABLE `atts_wp_cli_cookie_scan_categories` (
  `id_cli_cookie_category` int(11) NOT NULL,
  `cli_cookie_category_name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cli_cookie_category_description` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_cli_cookie_scan_cookies`
--

CREATE TABLE `atts_wp_cli_cookie_scan_cookies` (
  `id_cli_cookie_scan_cookies` int(11) NOT NULL,
  `id_cli_cookie_scan` int(11) NOT NULL DEFAULT '0',
  `id_cli_cookie_scan_url` int(11) NOT NULL DEFAULT '0',
  `cookie_id` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `expiry` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_cli_cookie_scan_url`
--

CREATE TABLE `atts_wp_cli_cookie_scan_url` (
  `id_cli_cookie_scan_url` int(11) NOT NULL,
  `id_cli_cookie_scan` int(11) NOT NULL DEFAULT '0',
  `url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scanned` int(11) NOT NULL DEFAULT '0',
  `total_cookies` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_cli_scripts`
--

CREATE TABLE `atts_wp_cli_scripts` (
  `id` int(11) NOT NULL,
  `cliscript_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_category` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_type` int(11) DEFAULT '0',
  `cliscript_status` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cliscript_key` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_cli_scripts`
--

INSERT INTO `atts_wp_cli_scripts` (`id`, `cliscript_title`, `cliscript_category`, `cliscript_type`, `cliscript_status`, `cliscript_description`, `cliscript_key`, `type`) VALUES
(1, 'Official Facebook Pixel', 'analytics', 1, 'yes', 'Official Facebook Pixel', 'facebook-for-wordpress', 0),
(2, 'Smash Balloon Twitter Feed', 'analytics', 1, 'yes', 'Twitter Feed By Smash Baloon', 'twitter-feed', 0),
(3, 'Smash Balloon Instagram Feed', 'advertisement', 1, 'yes', 'Instagram Feed By Smash Baloon', 'instagram-feed', 0),
(4, 'Google Analytics for WordPress by MonsterInsights', 'analytics', 1, 'yes', 'Google Analytics Dashboard Plugin for WordPress by MonsterInsights', 'google-analytics-for-wordpress', 0);

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_commentmeta`
--

CREATE TABLE `atts_wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_comments`
--

CREATE TABLE `atts_wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_comments`
--

INSERT INTO `atts_wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Um comentarista do WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-05-21 10:03:32', '2021-05-21 13:03:32', 'Olá, isso é um comentário.\nPara começar a moderar, editar e excluir comentários, visite a tela de Comentários no painel.\nAvatares de comentaristas vêm a partir do <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_links`
--

CREATE TABLE `atts_wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_mb_relationships`
--

CREATE TABLE `atts_wp_mb_relationships` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `from` bigint(20) UNSIGNED NOT NULL,
  `to` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(44) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_from` bigint(20) UNSIGNED NOT NULL,
  `order_to` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_options`
--

CREATE TABLE `atts_wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_options`
--

INSERT INTO `atts_wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888/hublife', 'yes'),
(2, 'home', 'http://localhost:8888/hublife', 'yes'),
(3, 'blogname', 'Hublife - Site para clínica, empresa ou profissional da área médica', 'yes'),
(4, 'blogdescription', 'Só mais um site WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'alex_freitas_dev@outlook.com', 'yes'),
(7, 'start_of_week', '0', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j \\d\\e F \\d\\e Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'j \\d\\e F \\d\\e Y, H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:127:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:41:\"cookielawinfo/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:51:\"cookielawinfo/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:71:\"cookielawinfo/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"cookielawinfo/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"cookielawinfo/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:47:\"cookielawinfo/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:30:\"cookielawinfo/([^/]+)/embed/?$\";s:46:\"index.php?cookielawinfo=$matches[1]&embed=true\";s:34:\"cookielawinfo/([^/]+)/trackback/?$\";s:40:\"index.php?cookielawinfo=$matches[1]&tb=1\";s:42:\"cookielawinfo/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?cookielawinfo=$matches[1]&paged=$matches[2]\";s:49:\"cookielawinfo/([^/]+)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?cookielawinfo=$matches[1]&cpage=$matches[2]\";s:38:\"cookielawinfo/([^/]+)(?:/([0-9]+))?/?$\";s:52:\"index.php?cookielawinfo=$matches[1]&page=$matches[2]\";s:30:\"cookielawinfo/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:40:\"cookielawinfo/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:60:\"cookielawinfo/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"cookielawinfo/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"cookielawinfo/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:36:\"cookielawinfo/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:63:\"cookielawinfo-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:75:\"index.php?taxonomy=cookielawinfo-category&term=$matches[1]&feed=$matches[2]\";s:58:\"cookielawinfo-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:75:\"index.php?taxonomy=cookielawinfo-category&term=$matches[1]&feed=$matches[2]\";s:39:\"cookielawinfo-category/([^/]+)/embed/?$\";s:69:\"index.php?taxonomy=cookielawinfo-category&term=$matches[1]&embed=true\";s:51:\"cookielawinfo-category/([^/]+)/page/?([0-9]{1,})/?$\";s:76:\"index.php?taxonomy=cookielawinfo-category&term=$matches[1]&paged=$matches[2]\";s:33:\"cookielawinfo-category/([^/]+)/?$\";s:58:\"index.php?taxonomy=cookielawinfo-category&term=$matches[1]\";s:32:\"banner/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"banner/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"banner/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"banner/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"banner/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"banner/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"banner/(.+?)/embed/?$\";s:39:\"index.php?banner=$matches[1]&embed=true\";s:25:\"banner/(.+?)/trackback/?$\";s:33:\"index.php?banner=$matches[1]&tb=1\";s:33:\"banner/(.+?)/page/?([0-9]{1,})/?$\";s:46:\"index.php?banner=$matches[1]&paged=$matches[2]\";s:40:\"banner/(.+?)/comment-page-([0-9]{1,})/?$\";s:46:\"index.php?banner=$matches[1]&cpage=$matches[2]\";s:29:\"banner/(.+?)(?:/([0-9]+))?/?$\";s:45:\"index.php?banner=$matches[1]&page=$matches[2]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:36:\"contact-form-7/wp-contact-form-7.php\";i:1;s:35:\"cookie-law-info/cookie-law-info.php\";i:2;s:32:\"duplicate-page/duplicatepage.php\";i:3;s:29:\"meta-box-aio/meta-box-aio.php\";i:4;s:21:\"meta-box/meta-box.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'hublife', 'yes'),
(41, 'stylesheet', 'hublife', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:35:\"cookie-law-info/cookie-law-info.php\";s:25:\"uninstall_cookie_law_info\";}', 'no'),
(80, 'timezone_string', 'America/Sao_Paulo', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1637154212', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'initial_db_version', '49752', 'yes'),
(99, 'atts_wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(100, 'fresh_site', '0', 'yes'),
(101, 'WPLANG', 'pt_BR', 'yes'),
(102, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(108, 'cron', 'a:7:{i:1621620213;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1621621392;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"d63aca0b7e6237c7964320bd7fc95644\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:7;}}}}i:1621645413;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1621688613;a:2:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1621688779;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1621688789;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(109, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:20:\"https_request_failed\";a:1:{i:0;s:26:\"Requisição HTTPS falhou.\";}}', 'yes'),
(122, 'theme_mods_twentytwentyone', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1621603292;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}', 'yes'),
(133, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:28:\"alex_freitas_dev@outlook.com\";s:7:\"version\";s:5:\"5.7.2\";s:9:\"timestamp\";i:1621602256;}', 'no'),
(135, 'can_compress_scripts', '1', 'no'),
(136, '_transient_timeout_dash_v2_01e18dead815ce736e3b9cccfbd773a5', '1621645612', 'no'),
(137, '_transient_dash_v2_01e18dead815ce736e3b9cccfbd773a5', '<div class=\"rss-widget\"><p><strong>Erro de RSS:</strong> WP HTTP Error: cURL error 28: Resolving timed out after 10002 milliseconds</p></div><div class=\"rss-widget\"><p><strong>Erro de RSS:</strong> WP HTTP Error: cURL error 28: Resolving timed out after 10001 milliseconds</p></div>', 'no'),
(140, 'finished_updating_comment_type', '1', 'yes'),
(141, 'current_theme', 'Hublife - Site para clínica, empresa ou profissional da área médica', 'yes'),
(142, 'theme_mods_hublife', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(143, 'theme_switched', '', 'yes'),
(144, 'recently_activated', 'a:0:{}', 'yes'),
(145, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.4.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1621605657;s:7:\"version\";s:5:\"5.4.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(147, 'secret_key', 'UhTY9RYnm8mm`Mu-xh<jMBb%a2mFM69U:/z^g5]l>{7;zu!A11|txyWd{OQ]DHiK', 'no'),
(153, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/pt_BR/wordpress-5.7.2.zip\";s:6:\"locale\";s:5:\"pt_BR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/pt_BR/wordpress-5.7.2.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.7.2\";s:7:\"version\";s:5:\"5.7.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1621614165;s:15:\"version_checked\";s:5:\"5.7.2\";s:12:\"translations\";a:0:{}}', 'no'),
(155, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1621614199;s:7:\"checked\";a:4:{s:7:\"hublife\";s:3:\"1.0\";s:14:\"twentynineteen\";s:3:\"2.0\";s:12:\"twentytwenty\";s:3:\"1.7\";s:15:\"twentytwentyone\";s:3:\"1.3\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:3:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.0.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.7.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.3.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(156, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1621624978', 'no'),
(157, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:\"stdClass\":100:{s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:4898;}s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4766;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2714;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2592;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:2000;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1855;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1833;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1513;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1504;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1498;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1490;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1479;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1470;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1310;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1259;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1247;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1229;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1151;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1125;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:1054;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:951;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:929;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:908;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:886;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:877;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:823;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:817;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:808;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:804;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:782;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:762;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:745;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:726;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:725;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:715;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:713;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:680;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:676;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:665;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:664;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:661;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:660;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:653;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:648;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:635;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:603;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:598;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:597;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:590;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:590;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:576;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:570;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:566;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:561;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:559;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:557;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:546;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:545;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:544;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:540;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:530;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:520;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:510;}s:9:\"elementor\";a:3:{s:4:\"name\";s:9:\"elementor\";s:4:\"slug\";s:9:\"elementor\";s:5:\"count\";i:505;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:502;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:500;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:496;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:493;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:488;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:486;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:476;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:464;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:459;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:455;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:447;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:445;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:445;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:443;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:443;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:441;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:432;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:425;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:420;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:410;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:409;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:408;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:405;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:400;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:392;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:390;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:388;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:380;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:379;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:376;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:371;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:364;}s:6:\"import\";a:3:{s:4:\"name\";s:6:\"import\";s:4:\"slug\";s:6:\"import\";s:5:\"count\";i:363;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:356;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:355;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:347;}}', 'no'),
(159, '_transient_timeout_meta_box_a814e4a439884c2aea747e49f7359324', '1621700602', 'no'),
(160, '_transient_meta_box_a814e4a439884c2aea747e49f7359324', 'a:2:{s:6:\"status\";s:7:\"invalid\";s:4:\"data\";a:0:{}}', 'no'),
(161, 'meta_box_updater', 'a:3:{s:6:\"status\";s:6:\"active\";s:7:\"plugins\";a:0:{}s:7:\"api_key\";s:32:\"a27e73b7452b0edc9e75eeb9b6b7dc6e\";}', 'yes'),
(162, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1621618418;s:7:\"checked\";a:5:{s:19:\"akismet/akismet.php\";s:5:\"4.1.9\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.4.1\";s:9:\"hello.php\";s:5:\"1.7.2\";s:21:\"meta-box/meta-box.php\";s:5:\"5.4.0\";s:29:\"meta-box-aio/meta-box-aio.php\";s:7:\"1.13.11\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.9\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.4.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.4.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:21:\"meta-box/meta-box.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/meta-box\";s:4:\"slug\";s:8:\"meta-box\";s:6:\"plugin\";s:21:\"meta-box/meta-box.php\";s:11:\"new_version\";s:5:\"5.4.0\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/meta-box/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/meta-box.5.4.0.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/meta-box/assets/icon-128x128.png?rev=1100915\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:63:\"https://ps.w.org/meta-box/assets/banner-772x250.png?rev=1929588\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(163, 'meta_box_aio', 'a:1:{s:10:\"extensions\";a:29:{i:0;s:16:\"mb-admin-columns\";i:1;s:9:\"mb-blocks\";i:2;s:15:\"mb-comment-meta\";i:3;s:19:\"mb-custom-post-type\";i:4;s:15:\"mb-custom-table\";i:5;s:22:\"mb-frontend-submission\";i:6;s:16:\"mb-relationships\";i:7;s:11:\"mb-rest-api\";i:8;s:11:\"mb-revision\";i:9;s:16:\"mb-settings-page\";i:10;s:12:\"mb-term-meta\";i:11;s:12:\"mb-user-meta\";i:12;s:15:\"mb-user-profile\";i:13;s:8:\"mb-views\";i:14;s:33:\"meta-box-beaver-themer-integrator\";i:15;s:16:\"meta-box-builder\";i:16;s:16:\"meta-box-columns\";i:17;s:26:\"meta-box-conditional-logic\";i:18;s:23:\"mb-elementor-integrator\";i:19;s:27:\"meta-box-facetwp-integrator\";i:20;s:20:\"meta-box-geolocation\";i:21;s:14:\"meta-box-group\";i:22;s:24:\"meta-box-include-exclude\";i:23;s:18:\"meta-box-show-hide\";i:24;s:13:\"meta-box-tabs\";i:25;s:17:\"meta-box-template\";i:26;s:21:\"meta-box-text-limiter\";i:27;s:16:\"meta-box-tooltip\";i:28;s:18:\"meta-box-yoast-seo\";}}', 'yes'),
(164, 'mbb_version', '4.1.5', 'yes'),
(165, '_transient_timeout_meta_box_247a61bfb7da9227f381a250f1d06bed', '1621700672', 'no'),
(166, '_transient_meta_box_247a61bfb7da9227f381a250f1d06bed', 'a:2:{s:6:\"status\";s:6:\"active\";s:4:\"data\";N;}', 'no'),
(168, '_transient_timeout_meta_box_3b2825ddf1d733e0423d67164368a5e7', '1621704823', 'no'),
(169, '_transient_meta_box_3b2825ddf1d733e0423d67164368a5e7', '', 'no'),
(170, 'wt_cli_start_date', '1621614658', 'yes'),
(171, '_transient_timeout__wt_cli_first_time_activation', '1621614688', 'no'),
(172, '_transient__wt_cli_first_time_activation', '1', 'no'),
(174, 'cookielawinfo_js_blocking', 'yes', 'yes'),
(175, '_transient_timeout_wt_cli_script_blocker_notice', '1621701058', 'no'),
(176, '_transient_wt_cli_script_blocker_notice', '1', 'no'),
(177, 'cli_script_blocker_status', 'enabled', 'yes'),
(178, 'wt_cli_cookie_db_version', '2.0', 'yes'),
(179, 'wt_cli_db_version', '2.0.1', 'yes'),
(180, 'wt_cli_version', '2.0.1', 'yes');
INSERT INTO `atts_wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(181, 'CookieLawInfo-0.9', 'a:98:{s:18:\"animate_speed_hide\";s:3:\"500\";s:18:\"animate_speed_show\";s:3:\"500\";s:10:\"background\";s:4:\"#FFF\";s:14:\"background_url\";s:0:\"\";s:6:\"border\";s:9:\"#b1a6a6c2\";s:9:\"border_on\";b:1;s:9:\"bar_style\";a:0:{}s:13:\"button_1_text\";s:7:\"Aceitar\";s:12:\"button_1_url\";s:1:\"#\";s:15:\"button_1_action\";s:27:\"#cookie_action_close_header\";s:20:\"button_1_link_colour\";s:4:\"#fff\";s:16:\"button_1_new_win\";b:0;s:18:\"button_1_as_button\";b:1;s:22:\"button_1_button_colour\";s:7:\"#b74a6b\";s:20:\"button_1_button_size\";s:6:\"medium\";s:14:\"button_1_style\";a:0:{}s:13:\"button_2_text\";s:9:\"Read More\";s:12:\"button_2_url\";s:29:\"http://localhost:8888/hublife\";s:15:\"button_2_action\";s:17:\"CONSTANT_OPEN_URL\";s:20:\"button_2_link_colour\";s:4:\"#444\";s:16:\"button_2_new_win\";b:1;s:18:\"button_2_as_button\";b:0;s:22:\"button_2_button_colour\";s:4:\"#333\";s:20:\"button_2_button_size\";s:6:\"medium\";s:17:\"button_2_url_type\";s:3:\"url\";s:13:\"button_2_page\";s:1:\"0\";s:16:\"button_2_hidebar\";b:0;s:14:\"button_2_style\";a:0:{}s:13:\"button_3_text\";s:6:\"REJECT\";s:12:\"button_3_url\";s:1:\"#\";s:15:\"button_3_action\";s:34:\"#cookie_action_close_header_reject\";s:20:\"button_3_link_colour\";s:4:\"#fff\";s:16:\"button_3_new_win\";b:0;s:18:\"button_3_as_button\";b:1;s:22:\"button_3_button_colour\";s:7:\"#3566bb\";s:20:\"button_3_button_size\";s:6:\"medium\";s:14:\"button_3_style\";a:0:{}s:13:\"button_4_text\";s:18:\"Configurar cookies\";s:12:\"button_4_url\";s:1:\"#\";s:15:\"button_4_action\";s:23:\"#cookie_action_settings\";s:20:\"button_4_link_colour\";s:7:\"#333333\";s:16:\"button_4_new_win\";b:0;s:18:\"button_4_as_button\";b:0;s:22:\"button_4_button_colour\";s:4:\"#000\";s:20:\"button_4_button_size\";s:6:\"medium\";s:14:\"button_4_style\";a:0:{}s:14:\"button_5_style\";a:0:{}s:13:\"button_7_text\";s:12:\"Aceitar Tudo\";s:12:\"button_7_url\";s:1:\"#\";s:15:\"button_7_action\";s:27:\"#cookie_action_close_header\";s:20:\"button_7_link_colour\";s:4:\"#fff\";s:16:\"button_7_new_win\";b:0;s:18:\"button_7_as_button\";b:1;s:22:\"button_7_button_colour\";s:7:\"#61a229\";s:20:\"button_7_button_size\";s:6:\"medium\";s:14:\"button_7_style\";a:0:{}s:11:\"font_family\";s:21:\"Helvetica, sans-serif\";s:10:\"header_fix\";b:0;s:5:\"is_on\";b:1;s:8:\"is_eu_on\";b:0;s:10:\"logging_on\";b:0;s:19:\"notify_animate_hide\";b:1;s:19:\"notify_animate_show\";b:0;s:13:\"notify_div_id\";s:20:\"#cookie-law-info-bar\";s:26:\"notify_position_horizontal\";s:5:\"right\";s:24:\"notify_position_vertical\";s:6:\"bottom\";s:14:\"notify_message\";s:386:\"<div class=\"cli-bar-container cli-style-v2\"><div class=\"cli-bar-message\">Usamos cookies em nosso site para fornecer a experiência mais relevante, lembrando suas preferências e visitas repetidas. Ao clicar em “Aceitar”, concorda com a utilização de TODOS os cookies.</div><div class=\"cli-bar-btn_container\">[cookie_settings margin=\\\"0px 10px 0px 5px\\\"][cookie_button]</div></div>\";s:12:\"scroll_close\";b:0;s:19:\"scroll_close_reload\";b:0;s:19:\"accept_close_reload\";b:0;s:19:\"reject_close_reload\";b:0;s:20:\"showagain_background\";s:4:\"#fff\";s:16:\"showagain_border\";s:4:\"#000\";s:14:\"showagain_text\";s:14:\"Manage consent\";s:16:\"showagain_div_id\";s:22:\"#cookie-law-info-again\";s:13:\"showagain_tab\";b:0;s:20:\"showagain_x_position\";s:5:\"100px\";s:4:\"text\";s:7:\"#333333\";s:17:\"use_colour_picker\";b:1;s:12:\"show_once_yn\";b:0;s:9:\"show_once\";s:5:\"10000\";s:9:\"is_GMT_on\";b:1;s:8:\"as_popup\";b:0;s:13:\"popup_overlay\";b:1;s:16:\"bar_heading_text\";s:0:\"\";s:13:\"cookie_bar_as\";s:6:\"widget\";s:24:\"popup_showagain_position\";s:12:\"bottom-right\";s:15:\"widget_position\";s:5:\"right\";s:12:\"ccpa_enabled\";b:0;s:16:\"button_6_as_link\";b:1;s:13:\"button_6_text\";s:35:\"Do not sell my personal information\";s:15:\"ccpa_enable_bar\";b:0;s:17:\"ccpa_region_based\";b:0;s:12:\"consent_type\";s:4:\"gdpr\";s:12:\"ccpa_content\";s:265:\"<div class=\"cli-bar-container cli-style-v2\"><div class=\"cli-bar-message\">This website or its third-party tools process personal data.</br>In case of sale of your personal information, you may opt out by using the link [wt_cli_ccpa_optout].</div>[cookie_close]</div>\";s:17:\"ccpa_gdpr_content\";s:442:\"<div class=\"cli-bar-container cli-style-v2\"><div class=\"cli-bar-message\">We use cookies on our website to give you the most relevant experience by remembering your preferences and repeat visits. By clicking “Accept”, you consent to the use of ALL the cookies.</br><div class=\"wt-cli-ccpa-element\"> [wt_cli_ccpa_optout].</div></div><div class=\"cli-bar-btn_container\">[cookie_settings margin=\\\"0px 10px 0px 5px\\\"][cookie_button]</div></div>\";s:12:\"gdpr_content\";s:386:\"<div class=\"cli-bar-container cli-style-v2\"><div class=\"cli-bar-message\">Usamos cookies em nosso site para fornecer a experiência mais relevante, lembrando suas preferências e visitas repetidas. Ao clicar em “Aceitar”, concorda com a utilização de TODOS os cookies.</div><div class=\"cli-bar-btn_container\">[cookie_settings margin=\\\"0px 10px 0px 5px\\\"][cookie_button]</div></div>\";s:20:\"button_6_link_colour\";s:7:\"#333333\";}', 'yes'),
(182, 'cookielawinfo_privacy_overview_content_settings', 'a:2:{s:24:\"privacy_overview_content\";s:552:\"This website uses cookies to improve your experience while you navigate through the website. Out of these, the cookies that are categorized as necessary are stored on your browser as they are essential for the working of basic functionalities of the website. We also use third-party cookies that help us analyze and understand how you use this website. These cookies will be stored in your browser only with your consent. You also have the option to opt-out of these cookies. But opting out of some of these cookies may affect your browsing experience.\";s:22:\"privacy_overview_title\";s:16:\"Privacy Overview\";}', 'yes'),
(184, '_site_transient_timeout_theme_roots', '1621619074', 'no'),
(185, '_site_transient_theme_roots', 'a:4:{s:7:\"hublife\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}', 'no'),
(186, 'duplicate_page_options', 'a:4:{s:21:\"duplicate_post_status\";s:5:\"draft\";s:23:\"duplicate_post_redirect\";s:7:\"to_list\";s:21:\"duplicate_post_suffix\";s:0:\"\";s:21:\"duplicate_post_editor\";s:7:\"classic\";}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_postmeta`
--

CREATE TABLE `atts_wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_postmeta`
--

INSERT INTO `atts_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_form', '<div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label for=\"nome-completo\" class=\"form-label-2\">Seu nome</label>[text* nome-completo class:form-input-2 class:w-input id:nome-completo placeholder \"Digite seu nome\"]</div></div><div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label for=\"email-contato\" class=\"form-label-2\">Seu e-mail</label>[email* email-contato class:form-input-2 class:w-input id:email-contato placeholder \"Digite seu e-mail\"]</div></div><div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label for=\"whatsapp\" class=\"form-label-2\">Seu Whatsapp</label>[text* Whatsapp class:sp_celphones class:phone-mask-pattern class:form-input-2 class:w-input id:Whatsapp placeholder \"(11) 98888-7777\"]</div></div><div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label class=\"label-termos\">[acceptance aceite class:iptAceite] <span>Aceito a <a href=\"#\" title=\"política de compartilhamento de dados\" target=\"_blank\">política de compartilhamento de dados</a> e <a href=\"#\" target=\"_blank\">termos de uso</a></span></label></div></div><div class=\"row row-justify-end\">[submit class:button-3 class:button-block class:w-button \"Enviar\"]</div>'),
(4, 5, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:44:\"[_site_title] <alex_freitas_dev@outlook.com>\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:4:\"body\";s:163:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(5, 5, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:44:\"[_site_title] <alex_freitas_dev@outlook.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:105:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(6, 5, '_messages', 'a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(7, 5, '_additional_settings', ''),
(8, 5, '_locale', 'pt_BR'),
(13, 8, '_edit_last', '1'),
(14, 8, '_edit_lock', '1621617336:1'),
(15, 9, '_wp_attached_file', '2021/05/banner.png'),
(16, 9, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:649;s:4:\"file\";s:18:\"2021/05/banner.png\";s:5:\"sizes\";a:14:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"banner-300x101.png\";s:5:\"width\";i:300;s:6:\"height\";i:101;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"banner-1024x346.png\";s:5:\"width\";i:1024;s:6:\"height\";i:346;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"banner-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"banner-768x260.png\";s:5:\"width\";i:768;s:6:\"height\";i:260;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:19:\"banner-1536x519.png\";s:5:\"width\";i:1536;s:6:\"height\";i:519;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:17:\"banner-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-340x245\";a:4:{s:4:\"file\";s:18:\"banner-340x245.png\";s:5:\"width\";i:340;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-315x400\";a:4:{s:4:\"file\";s:18:\"banner-315x400.png\";s:5:\"width\";i:315;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-375x375\";a:4:{s:4:\"file\";s:18:\"banner-375x375.png\";s:5:\"width\";i:375;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-565x310\";a:4:{s:4:\"file\";s:18:\"banner-565x310.png\";s:5:\"width\";i:565;s:6:\"height\";i:310;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-600x400\";a:4:{s:4:\"file\";s:18:\"banner-600x400.png\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-745x380\";a:4:{s:4:\"file\";s:18:\"banner-745x380.png\";s:5:\"width\";i:745;s:6:\"height\";i:380;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-800x325\";a:4:{s:4:\"file\";s:18:\"banner-800x325.png\";s:5:\"width\";i:800;s:6:\"height\";i:325;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"banner-1200x406.png\";s:5:\"width\";i:1200;s:6:\"height\";i:406;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(17, 8, '_thumbnail_id', '9'),
(18, 8, 'Banner_link', 'https://teste/link'),
(19, 8, 'Banner_target', '_self'),
(20, 8, 'Banner_btn', 'Saiba Mais'),
(21, 1, '_edit_lock', '1621618429:1'),
(22, 10, '_wp_attached_file', '2021/05/blog-01.png'),
(23, 10, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:433;s:6:\"height\";i:252;s:4:\"file\";s:19:\"2021/05/blog-01.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"blog-01-300x175.png\";s:5:\"width\";i:300;s:6:\"height\";i:175;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"blog-01-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:18:\"blog-01-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-340x245\";a:4:{s:4:\"file\";s:19:\"blog-01-340x245.png\";s:5:\"width\";i:340;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-315x400\";a:4:{s:4:\"file\";s:19:\"blog-01-315x252.png\";s:5:\"width\";i:315;s:6:\"height\";i:252;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-375x375\";a:4:{s:4:\"file\";s:19:\"blog-01-375x252.png\";s:5:\"width\";i:375;s:6:\"height\";i:252;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(24, 11, '_wp_attached_file', '2021/05/blog-02.png'),
(25, 11, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:418;s:6:\"height\";i:279;s:4:\"file\";s:19:\"2021/05/blog-02.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"blog-02-300x200.png\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"blog-02-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:18:\"blog-02-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-340x245\";a:4:{s:4:\"file\";s:19:\"blog-02-340x245.png\";s:5:\"width\";i:340;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-315x400\";a:4:{s:4:\"file\";s:19:\"blog-02-315x279.png\";s:5:\"width\";i:315;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-375x375\";a:4:{s:4:\"file\";s:19:\"blog-02-375x279.png\";s:5:\"width\";i:375;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(26, 12, '_wp_attached_file', '2021/05/blog-03.png'),
(27, 12, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:368;s:6:\"height\";i:245;s:4:\"file\";s:19:\"2021/05/blog-03.png\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"blog-03-300x200.png\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"blog-03-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:18:\"blog-03-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-340x245\";a:4:{s:4:\"file\";s:19:\"blog-03-340x245.png\";s:5:\"width\";i:340;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-315x400\";a:4:{s:4:\"file\";s:19:\"blog-03-315x245.png\";s:5:\"width\";i:315;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(28, 13, '_wp_attached_file', '2021/05/dif-02.png'),
(29, 13, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:587;s:6:\"height\";i:395;s:4:\"file\";s:18:\"2021/05/dif-02.png\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"dif-02-300x202.png\";s:5:\"width\";i:300;s:6:\"height\";i:202;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"dif-02-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:17:\"dif-02-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-340x245\";a:4:{s:4:\"file\";s:18:\"dif-02-340x245.png\";s:5:\"width\";i:340;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-315x400\";a:4:{s:4:\"file\";s:18:\"dif-02-315x395.png\";s:5:\"width\";i:315;s:6:\"height\";i:395;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-375x375\";a:4:{s:4:\"file\";s:18:\"dif-02-375x375.png\";s:5:\"width\";i:375;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-565x310\";a:4:{s:4:\"file\";s:18:\"dif-02-565x310.png\";s:5:\"width\";i:565;s:6:\"height\";i:310;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-745x380\";a:4:{s:4:\"file\";s:18:\"dif-02-587x380.png\";s:5:\"width\";i:587;s:6:\"height\";i:380;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-800x325\";a:4:{s:4:\"file\";s:18:\"dif-02-587x325.png\";s:5:\"width\";i:587;s:6:\"height\";i:325;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(30, 14, '_wp_attached_file', '2021/05/dif.png'),
(31, 14, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:587;s:6:\"height\";i:395;s:4:\"file\";s:15:\"2021/05/dif.png\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"dif-300x202.png\";s:5:\"width\";i:300;s:6:\"height\";i:202;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"dif-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:14:\"dif-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-340x245\";a:4:{s:4:\"file\";s:15:\"dif-340x245.png\";s:5:\"width\";i:340;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-315x400\";a:4:{s:4:\"file\";s:15:\"dif-315x395.png\";s:5:\"width\";i:315;s:6:\"height\";i:395;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-375x375\";a:4:{s:4:\"file\";s:15:\"dif-375x375.png\";s:5:\"width\";i:375;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-565x310\";a:4:{s:4:\"file\";s:15:\"dif-565x310.png\";s:5:\"width\";i:565;s:6:\"height\";i:310;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-745x380\";a:4:{s:4:\"file\";s:15:\"dif-587x380.png\";s:5:\"width\";i:587;s:6:\"height\";i:380;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-800x325\";a:4:{s:4:\"file\";s:15:\"dif-587x325.png\";s:5:\"width\";i:587;s:6:\"height\";i:325;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(32, 15, '_wp_attached_file', '2021/05/serv-01.png'),
(33, 15, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:198;s:6:\"height\";i:132;s:4:\"file\";s:19:\"2021/05/serv-01.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"serv-01-150x132.png\";s:5:\"width\";i:150;s:6:\"height\";i:132;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:18:\"serv-01-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(34, 16, '_wp_attached_file', '2021/05/serv-02.png'),
(35, 16, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:194;s:6:\"height\";i:129;s:4:\"file\";s:19:\"2021/05/serv-02.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"serv-02-150x129.png\";s:5:\"width\";i:150;s:6:\"height\";i:129;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:18:\"serv-02-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(36, 17, '_wp_attached_file', '2021/05/serv-03.png'),
(37, 17, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:195;s:6:\"height\";i:130;s:4:\"file\";s:19:\"2021/05/serv-03.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"serv-03-150x130.png\";s:5:\"width\";i:150;s:6:\"height\";i:130;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:18:\"serv-03-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(38, 18, '_wp_attached_file', '2021/05/video.png'),
(39, 18, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:780;s:6:\"height\";i:450;s:4:\"file\";s:17:\"2021/05/video.png\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"video-300x173.png\";s:5:\"width\";i:300;s:6:\"height\";i:173;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"video-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"video-768x443.png\";s:5:\"width\";i:768;s:6:\"height\";i:443;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"thumb-175x80\";a:4:{s:4:\"file\";s:16:\"video-175x80.png\";s:5:\"width\";i:175;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-340x245\";a:4:{s:4:\"file\";s:17:\"video-340x245.png\";s:5:\"width\";i:340;s:6:\"height\";i:245;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-315x400\";a:4:{s:4:\"file\";s:17:\"video-315x400.png\";s:5:\"width\";i:315;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-375x375\";a:4:{s:4:\"file\";s:17:\"video-375x375.png\";s:5:\"width\";i:375;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-565x310\";a:4:{s:4:\"file\";s:17:\"video-565x310.png\";s:5:\"width\";i:565;s:6:\"height\";i:310;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-600x400\";a:4:{s:4:\"file\";s:17:\"video-600x400.png\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-745x380\";a:4:{s:4:\"file\";s:17:\"video-745x380.png\";s:5:\"width\";i:745;s:6:\"height\";i:380;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"thumb-800x325\";a:4:{s:4:\"file\";s:17:\"video-780x325.png\";s:5:\"width\";i:780;s:6:\"height\";i:325;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(42, 1, '_thumbnail_id', '10'),
(43, 21, '_cli_cookie_type', '0'),
(44, 21, '_cli_cookie_duration', '11 months'),
(45, 21, '_cli_cookie_sensitivity', 'necessary'),
(46, 21, '_cli_cookie_slugid', 'viewed_cookie_policy'),
(47, 22, '_cli_cookie_type', '0'),
(48, 22, '_cli_cookie_duration', '11 months'),
(49, 22, '_cli_cookie_sensitivity', 'necessary'),
(50, 22, '_cli_cookie_slugid', 'cookielawinfo-checkbox-necessary'),
(51, 23, '_cli_cookie_type', '0'),
(52, 23, '_cli_cookie_duration', '11 months'),
(53, 23, '_cli_cookie_sensitivity', 'necessary'),
(54, 23, '_cli_cookie_slugid', 'cookielawinfo-checkbox-functional'),
(55, 24, '_cli_cookie_type', '0'),
(56, 24, '_cli_cookie_duration', '11 months'),
(57, 24, '_cli_cookie_sensitivity', 'necessary'),
(58, 24, '_cli_cookie_slugid', 'cookielawinfo-checkbox-performance'),
(59, 25, '_cli_cookie_type', '0'),
(60, 25, '_cli_cookie_duration', '11 months'),
(61, 25, '_cli_cookie_sensitivity', 'necessary'),
(62, 25, '_cli_cookie_slugid', 'cookielawinfo-checkbox-analytics'),
(63, 26, '_cli_cookie_type', '0'),
(64, 26, '_cli_cookie_duration', '11 months'),
(65, 26, '_cli_cookie_sensitivity', 'necessary'),
(66, 26, '_cli_cookie_slugid', 'cookielawinfo-checkbox-others'),
(70, 5, '_config_errors', 'a:1:{s:23:\"mail.additional_headers\";a:1:{i:0;a:2:{s:4:\"code\";i:102;s:4:\"args\";a:3:{s:7:\"message\";s:64:\"A sintaxe de caixa de e-mail usada no campo %name% é inválida.\";s:6:\"params\";a:1:{s:4:\"name\";s:8:\"Reply-To\";}s:4:\"link\";s:68:\"https://contactform7.com/configuration-errors/invalid-mailbox-syntax\";}}}}'),
(71, 27, '_edit_lock', '1621618411:1'),
(72, 27, '_thumbnail_id', '12'),
(74, 28, '_edit_lock', '1621618392:1'),
(75, 28, '_thumbnail_id', '11'),
(83, 32, '_edit_last', '1'),
(84, 32, '_edit_lock', '1621618592:1'),
(85, 32, '_thumbnail_id', '9'),
(86, 32, 'Banner_link', 'https://teste/link'),
(87, 32, 'Banner_target', '_self'),
(88, 32, 'Banner_btn', 'Saiba Mais'),
(90, 33, '_edit_last', '1'),
(91, 33, '_edit_lock', '1621618598:1'),
(92, 33, '_thumbnail_id', '9'),
(93, 33, 'Banner_link', 'https://teste/link'),
(94, 33, 'Banner_target', '_self'),
(95, 33, 'Banner_btn', 'Saiba Mais'),
(97, 34, '_edit_last', '1'),
(98, 34, '_edit_lock', '1621618604:1'),
(99, 34, '_thumbnail_id', '9'),
(100, 34, 'Banner_link', 'https://teste/link'),
(101, 34, 'Banner_target', '_self'),
(102, 34, 'Banner_btn', 'Saiba Mais'),
(104, 35, '_edit_last', '1'),
(105, 35, '_edit_lock', '1621618609:1'),
(106, 35, '_thumbnail_id', '9'),
(107, 35, 'Banner_link', 'https://teste/link'),
(108, 35, 'Banner_target', '_self'),
(109, 35, 'Banner_btn', 'Saiba Mais');

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_posts`
--

CREATE TABLE `atts_wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_posts`
--

INSERT INTO `atts_wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-05-21 10:03:32', '2021-05-21 13:03:32', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam aliquam, neque sed varius convallis, elit libero commodo leo, sed mollis ipsum nibh ut libero. Vestibulum sed...</p>\n<!-- /wp:paragraph -->', 'Lorem Ipsum is simply dummy', '', 'publish', 'open', 'open', '', 'ola-mundo', '', '', '2021-05-21 14:36:09', '2021-05-21 17:36:09', '', 0, 'http://localhost:8888/hublife/?p=1', 0, 'post', '', 1),
(2, 1, '2021-05-21 10:03:32', '2021-05-21 13:03:32', '<!-- wp:paragraph -->\n<p>Esta é uma página de exemplo. É diferente de um post no blog porque ela permanecerá em um lugar e aparecerá na navegação do seu site na maioria dos temas. Muitas pessoas começam com uma página que as apresenta a possíveis visitantes do site. Ela pode dizer algo assim:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Olá! Eu sou um mensageiro de bicicleta durante o dia, ator aspirante à noite, e este é o meu site. Eu moro em São Paulo, tenho um grande cachorro chamado Rex e gosto de tomar caipirinha (e banhos de chuva).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...ou alguma coisa assim:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>A Companhia de Miniaturas XYZ foi fundada em 1971, e desde então tem fornecido miniaturas de qualidade ao público. Localizada na cidade de Itu, a XYZ emprega mais de 2.000 pessoas e faz coisas grandiosas para a comunidade da cidade.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Como um novo usuário do WordPress, você deveria ir ao <a href=\"http://localhost:8888/hublife/wp-admin/\">painel</a> para excluir essa página e criar novas páginas para o seu conteúdo. Divirta-se!</p>\n<!-- /wp:paragraph -->', 'Página de exemplo', '', 'publish', 'closed', 'open', '', 'pagina-exemplo', '', '', '2021-05-21 10:03:32', '2021-05-21 13:03:32', '', 0, 'http://localhost:8888/hublife/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-05-21 10:03:32', '2021-05-21 13:03:32', '<!-- wp:heading --><h2>Quem somos</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>O endereço do nosso site é: http://localhost:8888/hublife.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comentários</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Quando os visitantes deixam comentários no site, coletamos os dados mostrados no formulário de comentários, além do endereço de IP e de dados do navegador do visitante, para auxiliar na detecção de spam.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Uma sequência anonimizada de caracteres criada a partir do seu e-mail (também chamada de hash) poderá ser enviada para o Gravatar para verificar se você usa o serviço. A política de privacidade do Gravatar está disponível aqui: https://automattic.com/privacy/. Depois da aprovação do seu comentário, a foto do seu perfil fica visível publicamente junto de seu comentário.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Mídia</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Se você envia imagens para o site, evite enviar as que contenham dados de localização incorporados (EXIF GPS). Visitantes podem baixar estas imagens do site e extrair delas seus dados de localização.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Ao deixar um comentário no site, você poderá optar por salvar seu nome, e-mail e site nos cookies. Isso visa seu conforto, assim você não precisará preencher seus  dados novamente quando fizer outro comentário. Estes cookies duram um ano.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se você tem uma conta e acessa este site, um cookie temporário será criado para determinar se seu navegador aceita cookies. Ele não contém nenhum dado pessoal e será descartado quando você fechar seu navegador.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Quando você acessa sua conta no site, também criamos vários cookies para salvar os dados da sua conta e suas escolhas de exibição de tela. Cookies de login são mantidos por dois dias e cookies de opções de tela por um ano. Se você selecionar &quot;Lembrar-me&quot;, seu acesso será mantido por duas semanas. Se você se desconectar da sua conta, os cookies de login serão removidos.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se você editar ou publicar um artigo, um cookie adicional será salvo no seu navegador. Este cookie não inclui nenhum dado pessoal e simplesmente indica o ID do post referente ao artigo que você acabou de editar. Ele expira depois de 1 dia.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Mídia incorporada de outros sites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Artigos neste site podem incluir conteúdo incorporado como, por exemplo, vídeos, imagens, artigos, etc. Conteúdos incorporados de outros sites se comportam exatamente da mesma forma como se o visitante estivesse visitando o outro site.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Estes sites podem coletar dados sobre você, usar cookies, incorporar rastreamento adicional de terceiros e monitorar sua interação com este conteúdo incorporado, incluindo sua interação com o conteúdo incorporado se você tem uma conta e está conectado com o site.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Com quem partilhamos seus dados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Se você solicitar uma redefinição de senha, seu endereço de IP será incluído no e-mail de redefinição de senha.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Por quanto tempo mantemos os seus dados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Se você deixar um comentário, o comentário e os seus metadados são conservados indefinidamente. Fazemos isso para que seja possível reconhecer e aprovar automaticamente qualquer comentário posterior ao invés de retê-lo para moderação.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Para usuários que se registram no nosso site (se houver), também guardamos as informações pessoais que fornecem no seu perfil de usuário. Todos os usuários podem ver, editar ou excluir suas informações pessoais a qualquer momento (só não é possível alterar o seu username). Os administradores de sites também podem ver e editar estas informações.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Quais os seus direitos sobre seus dados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Se você tiver uma conta neste site ou se tiver deixado comentários, pode solicitar um arquivo exportado dos dados pessoais que mantemos sobre você, inclusive quaisquer dados que nos tenha fornecido. Também pode solicitar que removamos qualquer dado pessoal que mantemos sobre você. Isto não inclui nenhuns dados que somos obrigados a manter para propósitos administrativos, legais ou de segurança.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Para onde enviamos seus dados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Texto sugerido: </strong>Comentários de visitantes podem ser marcados por um serviço automático de detecção de spam.</p><!-- /wp:paragraph -->', 'Política de privacidade', '', 'draft', 'closed', 'open', '', 'politica-de-privacidade', '', '', '2021-05-21 10:03:32', '2021-05-21 13:03:32', '', 0, 'http://localhost:8888/hublife/?page_id=3', 0, 'page', '', 0),
(4, 1, '2021-05-21 10:06:29', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-05-21 10:06:29', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/hublife/?p=4', 0, 'post', '', 0),
(5, 1, '2021-05-21 11:00:57', '2021-05-21 14:00:57', '<div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label for=\"nome-completo\" class=\"form-label-2\">Seu nome</label>[text* nome-completo class:form-input-2 class:w-input id:nome-completo placeholder \"Digite seu nome\"]</div></div><div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label for=\"email-contato\" class=\"form-label-2\">Seu e-mail</label>[email* email-contato class:form-input-2 class:w-input id:email-contato placeholder \"Digite seu e-mail\"]</div></div><div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label for=\"whatsapp\" class=\"form-label-2\">Seu Whatsapp</label>[text* Whatsapp class:sp_celphones class:phone-mask-pattern class:form-input-2 class:w-input id:Whatsapp placeholder \"(11) 98888-7777\"]</div></div><div class=\"w-layout-grid form-grid-halves-2\"><div class=\"form-group\"><label class=\"label-termos\">[acceptance aceite class:iptAceite] <span>Aceito a <a href=\"#\" title=\"política de compartilhamento de dados\" target=\"_blank\" rel=\"noopener\">política de compartilhamento de dados</a> e <a href=\"#\" target=\"_blank\" rel=\"noopener\">termos de uso</a></span></label></div></div><div class=\"row row-justify-end\">[submit class:button-3 class:button-block class:w-button \"Enviar\"]</div>\n1\n[_site_title] \"[your-subject]\"\n[_site_title] <alex_freitas_dev@outlook.com>\n[_site_admin_email]\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [your-email]\n\n\n\n\n[_site_title] \"[your-subject]\"\n[_site_title] <alex_freitas_dev@outlook.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Form Orçamento', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2021-05-21 14:01:11', '2021-05-21 17:01:11', '', 0, 'http://localhost:8888/hublife/?post_type=wpcf7_contact_form&#038;p=5', 0, 'wpcf7_contact_form', '', 0),
(6, 1, '2021-05-21 13:13:21', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-05-21 13:13:21', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/hublife/?post_type=banner&p=6', 0, 'banner', '', 0),
(8, 1, '2021-05-21 13:27:04', '2021-05-21 16:27:04', 'Excelência em advocacia judicial e consultoria empresarial para pequenas, médias e grandes empresas, inclusive multinacionais.\r\n\r\n<a data-fancybox=\"\" data-src=\"#form-orcamento\">Saiba mais</a>', 'Hublife conhecimento e modernidade', '', 'publish', 'closed', 'closed', '', 'hublife-conhecimento-e-modernidade', '', '', '2021-05-21 14:17:13', '2021-05-21 17:17:13', '', 0, 'http://localhost:8888/hublife/?post_type=banner&#038;p=8', 0, 'banner', '', 0),
(9, 1, '2021-05-21 13:26:49', '2021-05-21 16:26:49', '', 'Banner', '', 'inherit', 'open', 'closed', '', 'banner', '', '', '2021-05-21 13:26:49', '2021-05-21 16:26:49', '', 8, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/banner.png', 0, 'attachment', 'image/png', 0),
(10, 1, '2021-05-21 13:28:21', '2021-05-21 16:28:21', '', 'blog-01', '', 'inherit', 'open', 'closed', '', 'blog-01', '', '', '2021-05-21 13:28:21', '2021-05-21 16:28:21', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/blog-01.png', 0, 'attachment', 'image/png', 0),
(11, 1, '2021-05-21 13:28:22', '2021-05-21 16:28:22', '', 'blog-02', '', 'inherit', 'open', 'closed', '', 'blog-02', '', '', '2021-05-21 13:28:22', '2021-05-21 16:28:22', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/blog-02.png', 0, 'attachment', 'image/png', 0),
(12, 1, '2021-05-21 13:28:24', '2021-05-21 16:28:24', '', 'blog-03', '', 'inherit', 'open', 'closed', '', 'blog-03', '', '', '2021-05-21 13:28:24', '2021-05-21 16:28:24', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/blog-03.png', 0, 'attachment', 'image/png', 0),
(13, 1, '2021-05-21 13:28:25', '2021-05-21 16:28:25', '', 'dif-02', '', 'inherit', 'open', 'closed', '', 'dif-02', '', '', '2021-05-21 13:28:25', '2021-05-21 16:28:25', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/dif-02.png', 0, 'attachment', 'image/png', 0),
(14, 1, '2021-05-21 13:28:27', '2021-05-21 16:28:27', '', 'dif', '', 'inherit', 'open', 'closed', '', 'dif', '', '', '2021-05-21 13:28:27', '2021-05-21 16:28:27', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/dif.png', 0, 'attachment', 'image/png', 0),
(15, 1, '2021-05-21 13:28:29', '2021-05-21 16:28:29', '', 'serv-01', '', 'inherit', 'open', 'closed', '', 'serv-01', '', '', '2021-05-21 13:28:29', '2021-05-21 16:28:29', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/serv-01.png', 0, 'attachment', 'image/png', 0),
(16, 1, '2021-05-21 13:28:30', '2021-05-21 16:28:30', '', 'serv-02', '', 'inherit', 'open', 'closed', '', 'serv-02', '', '', '2021-05-21 13:28:30', '2021-05-21 16:28:30', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/serv-02.png', 0, 'attachment', 'image/png', 0),
(17, 1, '2021-05-21 13:28:31', '2021-05-21 16:28:31', '', 'serv-03', '', 'inherit', 'open', 'closed', '', 'serv-03', '', '', '2021-05-21 13:28:31', '2021-05-21 16:28:31', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/serv-03.png', 0, 'attachment', 'image/png', 0),
(18, 1, '2021-05-21 13:28:32', '2021-05-21 16:28:32', '', 'video', '', 'inherit', 'open', 'closed', '', 'video', '', '', '2021-05-21 13:28:32', '2021-05-21 16:28:32', '', 1, 'http://localhost:8888/hublife/wp-content/uploads/2021/05/video.png', 0, 'attachment', 'image/png', 0),
(21, 1, '2021-05-21 13:31:01', '2021-05-21 16:31:01', 'The cookie is set by the GDPR Cookie Consent plugin and is used to store whether or not user has consented to the use of cookies. It does not store any personal data.', 'viewed_cookie_policy', '', 'publish', 'closed', 'closed', '', 'viewed_cookie_policy', '', '', '2021-05-21 13:31:01', '2021-05-21 16:31:01', '', 0, 'http://localhost:8888/hublife/cookielawinfo/viewed_cookie_policy/', 0, 'cookielawinfo', '', 0),
(22, 1, '2021-05-21 13:31:01', '2021-05-21 16:31:01', 'This cookie is set by GDPR Cookie Consent plugin. The cookies is used to store the user consent for the cookies in the category \"Necessary\".', 'cookielawinfo-checkbox-necessary', '', 'publish', 'closed', 'closed', '', 'cookielawinfo-checkbox-necessary', '', '', '2021-05-21 13:31:01', '2021-05-21 16:31:01', '', 0, 'http://localhost:8888/hublife/cookielawinfo/cookielawinfo-checkbox-necessary/', 0, 'cookielawinfo', '', 0),
(23, 1, '2021-05-21 13:31:01', '2021-05-21 16:31:01', 'The cookie is set by GDPR cookie consent to record the user consent for the cookies in the category \"Functional\".', 'cookielawinfo-checbox-functional', '', 'publish', 'closed', 'closed', '', 'cookielawinfo-checkbox-functional', '', '', '2021-05-21 13:31:01', '2021-05-21 16:31:01', '', 0, 'http://localhost:8888/hublife/cookielawinfo/cookielawinfo-checkbox-functional/', 0, 'cookielawinfo', '', 0),
(24, 1, '2021-05-21 13:31:01', '2021-05-21 16:31:01', 'This cookie is set by GDPR Cookie Consent plugin. The cookie is used to store the user consent for the cookies in the category \"Performance\".', 'cookielawinfo-checkbox-performance', '', 'publish', 'closed', 'closed', '', 'cookielawinfo-checkbox-performance', '', '', '2021-05-21 13:31:01', '2021-05-21 16:31:01', '', 0, 'http://localhost:8888/hublife/cookielawinfo/cookielawinfo-checkbox-performance/', 0, 'cookielawinfo', '', 0),
(25, 1, '2021-05-21 13:31:01', '2021-05-21 16:31:01', 'This cookie is set by GDPR Cookie Consent plugin. The cookie is used to store the user consent for the cookies in the category \"Analytics\".', 'cookielawinfo-checbox-analytics', '', 'publish', 'closed', 'closed', '', 'cookielawinfo-checkbox-analytics', '', '', '2021-05-21 13:31:01', '2021-05-21 16:31:01', '', 0, 'http://localhost:8888/hublife/cookielawinfo/cookielawinfo-checkbox-analytics/', 0, 'cookielawinfo', '', 0),
(26, 1, '2021-05-21 13:31:01', '2021-05-21 16:31:01', 'This cookie is set by GDPR Cookie Consent plugin. The cookie is used to store the user consent for the cookies in the category \"Other.', 'cookielawinfo-checbox-others', '', 'publish', 'closed', 'closed', '', 'cookielawinfo-checkbox-others', '', '', '2021-05-21 13:31:01', '2021-05-21 16:31:01', '', 0, 'http://localhost:8888/hublife/cookielawinfo/cookielawinfo-checkbox-others/', 0, 'cookielawinfo', '', 0),
(27, 1, '2021-05-21 14:35:51', '2021-05-21 17:35:51', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam aliquam, neque sed varius convallis, elit libero commodo leo, sed mollis ipsum nibh ut libero. Vestibulum sed...</p>\n<!-- /wp:paragraph -->', 'Lorem Ipsum is simply dummy', '', 'publish', 'open', 'open', '', 'lorem-ipsum-is-simply-dummy-2', '', '', '2021-05-21 14:35:51', '2021-05-21 17:35:51', '', 0, 'http://localhost:8888/hublife/?p=27', 0, 'post', '', 0),
(28, 1, '2021-05-21 14:35:34', '2021-05-21 17:35:34', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam aliquam, neque sed varius convallis, elit libero commodo leo, sed mollis ipsum nibh ut libero. Vestibulum sed...</p>\n<!-- /wp:paragraph -->', 'Lorem Ipsum is simply dummy', '', 'publish', 'open', 'open', '', 'lorem-ipsum-is-simply-dummy', '', '', '2021-05-21 14:35:34', '2021-05-21 17:35:34', '', 0, 'http://localhost:8888/hublife/?p=28', 0, 'post', '', 0),
(32, 1, '2021-05-21 14:36:16', '2021-05-21 17:36:16', 'Excelência em advocacia judicial e consultoria empresarial para pequenas, médias e grandes empresas, inclusive multinacionais.\r\n\r\n<a data-fancybox=\"\" data-src=\"#form-orcamento\">Saiba mais</a>', 'Hublife conhecimento e modernidade', '', 'publish', 'closed', 'closed', '', 'hublife-conhecimento-e-modernidade-2', '', '', '2021-05-21 14:36:32', '2021-05-21 17:36:32', '', 0, 'http://localhost:8888/hublife/?post_type=banner&#038;p=32', 0, 'banner', '', 0),
(33, 1, '2021-05-21 14:36:20', '2021-05-21 17:36:20', 'Excelência em advocacia judicial e consultoria empresarial para pequenas, médias e grandes empresas, inclusive multinacionais.\r\n\r\n<a data-fancybox=\"\" data-src=\"#form-orcamento\">Saiba mais</a>', 'Hublife conhecimento e modernidade', '', 'publish', 'closed', 'closed', '', 'hublife-conhecimento-e-modernidade-3', '', '', '2021-05-21 14:36:38', '2021-05-21 17:36:38', '', 0, 'http://localhost:8888/hublife/?post_type=banner&#038;p=33', 0, 'banner', '', 0),
(34, 1, '2021-05-21 14:36:23', '2021-05-21 17:36:23', 'Excelência em advocacia judicial e consultoria empresarial para pequenas, médias e grandes empresas, inclusive multinacionais.\r\n\r\n<a data-fancybox=\"\" data-src=\"#form-orcamento\">Saiba mais</a>', 'Hublife conhecimento e modernidade', '', 'publish', 'closed', 'closed', '', 'hublife-conhecimento-e-modernidade-4', '', '', '2021-05-21 14:36:44', '2021-05-21 17:36:44', '', 0, 'http://localhost:8888/hublife/?post_type=banner&#038;p=34', 0, 'banner', '', 0),
(35, 1, '2021-05-21 14:36:26', '2021-05-21 17:36:26', 'Excelência em advocacia judicial e consultoria empresarial para pequenas, médias e grandes empresas, inclusive multinacionais.\r\n\r\n<a data-fancybox=\"\" data-src=\"#form-orcamento\">Saiba mais</a>', 'Hublife conhecimento e modernidade', '', 'publish', 'closed', 'closed', '', 'hublife-conhecimento-e-modernidade-5', '', '', '2021-05-21 14:36:49', '2021-05-21 17:36:49', '', 0, 'http://localhost:8888/hublife/?post_type=banner&#038;p=35', 0, 'banner', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_termmeta`
--

CREATE TABLE `atts_wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_termmeta`
--

INSERT INTO `atts_wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 2, 'CLIdefaultstate', 'disabled'),
(2, 2, '_cli_cookie_head_scripts', ''),
(3, 2, '_cli_cookie_body_scripts', ''),
(4, 2, 'CLIpriority', '0'),
(5, 3, 'CLIdefaultstate', 'disabled'),
(6, 3, '_cli_cookie_head_scripts', ''),
(7, 3, '_cli_cookie_body_scripts', ''),
(8, 3, 'CLIpriority', '5'),
(9, 4, 'CLIdefaultstate', 'disabled'),
(10, 4, '_cli_cookie_head_scripts', ''),
(11, 4, '_cli_cookie_body_scripts', ''),
(12, 4, 'CLIpriority', '4'),
(13, 5, 'CLIdefaultstate', 'disabled'),
(14, 5, '_cli_cookie_head_scripts', ''),
(15, 5, '_cli_cookie_body_scripts', ''),
(16, 5, 'CLIpriority', '3'),
(17, 6, 'CLIdefaultstate', 'disabled'),
(18, 6, '_cli_cookie_head_scripts', ''),
(19, 6, '_cli_cookie_body_scripts', ''),
(20, 6, 'CLIpriority', '2'),
(21, 7, 'CLIdefaultstate', 'disabled'),
(22, 7, '_cli_cookie_head_scripts', ''),
(23, 7, '_cli_cookie_body_scripts', ''),
(24, 7, 'CLIpriority', '1');

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_terms`
--

CREATE TABLE `atts_wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_terms`
--

INSERT INTO `atts_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sem categoria', 'sem-categoria', 0),
(2, 'Necessary', 'necessary', 0),
(3, 'Functional', 'functional', 0),
(4, 'Performance', 'performance', 0),
(5, 'Analytics', 'analytics', 0),
(6, 'Advertisement', 'advertisement', 0),
(7, 'Others', 'others', 0);

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_term_relationships`
--

CREATE TABLE `atts_wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_term_relationships`
--

INSERT INTO `atts_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(24, 2, 0),
(25, 2, 0),
(26, 2, 0),
(27, 1, 0),
(28, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_term_taxonomy`
--

CREATE TABLE `atts_wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_term_taxonomy`
--

INSERT INTO `atts_wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'cookielawinfo-category', 'Necessary cookies are absolutely essential for the website to function properly. These cookies ensure basic functionalities and security features of the website, anonymously.\n[cookie_audit category=\"necessary\" style=\"winter\" columns=\"cookie,duration,description\"]', 0, 6),
(3, 3, 'cookielawinfo-category', 'Functional cookies help to perform certain functionalities like sharing the content of the website on social media platforms, collect feedbacks, and other third-party features.\n[cookie_audit category=\"functional\" style=\"winter\" columns=\"cookie,duration,description\"]', 0, 0),
(4, 4, 'cookielawinfo-category', 'Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.\n[cookie_audit category=\"performance\" style=\"winter\" columns=\"cookie,duration,description\"]', 0, 0),
(5, 5, 'cookielawinfo-category', 'Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics the number of visitors, bounce rate, traffic source, etc.\n[cookie_audit category=\"analytics\" style=\"winter\" columns=\"cookie,duration,description\"]', 0, 0),
(6, 6, 'cookielawinfo-category', 'Advertisement cookies are used to provide visitors with relevant ads and marketing campaigns. These cookies track visitors across websites and collect information to provide customized ads.\n[cookie_audit category=\"advertisement\" style=\"winter\" columns=\"cookie,duration,description\"]', 0, 0),
(7, 7, 'cookielawinfo-category', 'Other uncategorized cookies are those that are being analyzed and have not been classified into a category as yet.\n[cookie_audit category=\"others\" style=\"winter\" columns=\"cookie,duration,description\"]', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_usermeta`
--

CREATE TABLE `atts_wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_usermeta`
--

INSERT INTO `atts_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'atts_wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'atts_wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:5:{s:64:\"d9d549d6e52b6c0446338895892d6fa5ea221746573465d362f518d5a3e0041e\";a:4:{s:10:\"expiration\";i:1621775178;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\";s:5:\"login\";i:1621602378;}s:64:\"b76f10ddca88a734cd6ec11412afac16a96aa8ccfb9ed84cdf689adbf69383af\";a:4:{s:10:\"expiration\";i:1621786336;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\";s:5:\"login\";i:1621613536;}s:64:\"8a4d063e261aee15f9f37d514b7eaaa5f683012fbc8b5ffd64ab3ac60b84f0bd\";a:4:{s:10:\"expiration\";i:1622823185;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\";s:5:\"login\";i:1621613585;}s:64:\"bc2e92d176e2103bb37f30054ac1e96b8466021ab13968bc854ef90104eb5d7c\";a:4:{s:10:\"expiration\";i:1621787235;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\";s:5:\"login\";i:1621614435;}s:64:\"426bfc084a7583dba02900d7d9ef53a9c399d226dd350a2354169016e9e0c943\";a:4:{s:10:\"expiration\";i:1621791092;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\";s:5:\"login\";i:1621618292;}}'),
(17, 1, 'atts_wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'atts_wp_user-settings', 'libraryContent=browse&editor=html'),
(19, 1, 'atts_wp_user-settings-time', '1621617429');

-- --------------------------------------------------------

--
-- Table structure for table `atts_wp_users`
--

CREATE TABLE `atts_wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `atts_wp_users`
--

INSERT INTO `atts_wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BVQQBqZbZVFbxThrQ7cBppZRs.k7J2/', 'admin', 'alex_freitas_dev@outlook.com', 'http://localhost:8888/hublife', '2021-05-21 13:03:32', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `atts_wp_cli_cookie_scan`
--
ALTER TABLE `atts_wp_cli_cookie_scan`
  ADD PRIMARY KEY (`id_cli_cookie_scan`);

--
-- Indexes for table `atts_wp_cli_cookie_scan_categories`
--
ALTER TABLE `atts_wp_cli_cookie_scan_categories`
  ADD PRIMARY KEY (`id_cli_cookie_category`),
  ADD UNIQUE KEY `cookie` (`cli_cookie_category_name`);

--
-- Indexes for table `atts_wp_cli_cookie_scan_cookies`
--
ALTER TABLE `atts_wp_cli_cookie_scan_cookies`
  ADD PRIMARY KEY (`id_cli_cookie_scan_cookies`),
  ADD UNIQUE KEY `cookie` (`id_cli_cookie_scan`,`cookie_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `atts_wp_cli_cookie_scan_url`
--
ALTER TABLE `atts_wp_cli_cookie_scan_url`
  ADD PRIMARY KEY (`id_cli_cookie_scan_url`);

--
-- Indexes for table `atts_wp_cli_scripts`
--
ALTER TABLE `atts_wp_cli_scripts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `atts_wp_commentmeta`
--
ALTER TABLE `atts_wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `atts_wp_comments`
--
ALTER TABLE `atts_wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `atts_wp_links`
--
ALTER TABLE `atts_wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `atts_wp_mb_relationships`
--
ALTER TABLE `atts_wp_mb_relationships`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `from` (`from`),
  ADD KEY `to` (`to`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `atts_wp_options`
--
ALTER TABLE `atts_wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `atts_wp_postmeta`
--
ALTER TABLE `atts_wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `atts_wp_posts`
--
ALTER TABLE `atts_wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `atts_wp_termmeta`
--
ALTER TABLE `atts_wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `atts_wp_terms`
--
ALTER TABLE `atts_wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `atts_wp_term_relationships`
--
ALTER TABLE `atts_wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `atts_wp_term_taxonomy`
--
ALTER TABLE `atts_wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `atts_wp_usermeta`
--
ALTER TABLE `atts_wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `atts_wp_users`
--
ALTER TABLE `atts_wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `atts_wp_cli_cookie_scan`
--
ALTER TABLE `atts_wp_cli_cookie_scan`
  MODIFY `id_cli_cookie_scan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `atts_wp_cli_cookie_scan_categories`
--
ALTER TABLE `atts_wp_cli_cookie_scan_categories`
  MODIFY `id_cli_cookie_category` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `atts_wp_cli_cookie_scan_cookies`
--
ALTER TABLE `atts_wp_cli_cookie_scan_cookies`
  MODIFY `id_cli_cookie_scan_cookies` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `atts_wp_cli_cookie_scan_url`
--
ALTER TABLE `atts_wp_cli_cookie_scan_url`
  MODIFY `id_cli_cookie_scan_url` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `atts_wp_cli_scripts`
--
ALTER TABLE `atts_wp_cli_scripts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `atts_wp_commentmeta`
--
ALTER TABLE `atts_wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `atts_wp_comments`
--
ALTER TABLE `atts_wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `atts_wp_links`
--
ALTER TABLE `atts_wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `atts_wp_mb_relationships`
--
ALTER TABLE `atts_wp_mb_relationships`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `atts_wp_options`
--
ALTER TABLE `atts_wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `atts_wp_postmeta`
--
ALTER TABLE `atts_wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `atts_wp_posts`
--
ALTER TABLE `atts_wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `atts_wp_termmeta`
--
ALTER TABLE `atts_wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `atts_wp_terms`
--
ALTER TABLE `atts_wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `atts_wp_term_taxonomy`
--
ALTER TABLE `atts_wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `atts_wp_usermeta`
--
ALTER TABLE `atts_wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `atts_wp_users`
--
ALTER TABLE `atts_wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `atts_wp_cli_cookie_scan_cookies`
--
ALTER TABLE `atts_wp_cli_cookie_scan_cookies`
  ADD CONSTRAINT `atts_wp_cli_cookie_scan_cookies_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `atts_wp_cli_cookie_scan_categories` (`id_cli_cookie_category`),
  ADD CONSTRAINT `atts_wp_cli_cookie_scan_cookies_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `atts_wp_cli_cookie_scan_categories` (`id_cli_cookie_category`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
